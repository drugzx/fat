# fatal3k
A new generation of xmpp (jabber) bot written on Python 3.0
